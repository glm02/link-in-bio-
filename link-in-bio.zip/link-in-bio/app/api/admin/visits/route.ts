import { NextRequest, NextResponse } from "next/server";
import { getVisits, clearVisits } from "@/lib/kv";

export const runtime = "nodejs";

function isAuthorized(req: NextRequest): boolean {
  const adminKey = process.env.ADMIN_KEY;
  if (!adminKey) return false;

  // Check Authorization header (Bearer token)
  const authHeader = req.headers.get("authorization");
  if (authHeader === `Bearer ${adminKey}`) return true;

  // Check query param fallback
  const url = new URL(req.url);
  if (url.searchParams.get("key") === adminKey) return true;

  return false;
}

export async function GET(req: NextRequest): Promise<NextResponse> {
  if (!isAuthorized(req)) {
    return NextResponse.json({ error: "Accès refusé" }, { status: 401 });
  }

  try {
    const visits = await getVisits();
    return NextResponse.json({ visits });
  } catch (err) {
    console.error("[admin/visits] GET error:", err);
    return NextResponse.json({ error: "Erreur serveur" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest): Promise<NextResponse> {
  if (!isAuthorized(req)) {
    return NextResponse.json({ error: "Accès refusé" }, { status: 401 });
  }

  try {
    await clearVisits();
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("[admin/visits] DELETE error:", err);
    return NextResponse.json({ error: "Erreur serveur" }, { status: 500 });
  }
}
