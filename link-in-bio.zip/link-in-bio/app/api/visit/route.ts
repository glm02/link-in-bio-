import { NextRequest, NextResponse } from "next/server";
import { v4 as uuidv4 } from "uuid";
import { pushVisit, type VisitRecord } from "@/lib/kv";
import { getGeoFromIP, truncateIP } from "@/lib/geo";

export const runtime = "nodejs";

export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    // Extract IP
    const forwarded = req.headers.get("x-forwarded-for");
    const realIp = req.headers.get("x-real-ip");
    const ip = forwarded?.split(",")[0]?.trim() ?? realIp ?? "0.0.0.0";

    const userAgent = req.headers.get("user-agent") ?? "Inconnu";
    const referer = req.headers.get("referer") ?? "Direct";

    // Cookie-based visitor fingerprint
    const existingId = req.cookies.get("visitorId")?.value;
    const isReturning = !!existingId;
    const visitorId = existingId ?? uuidv4();

    // Geolocation (fire & forget style, with timeout)
    const geo = await getGeoFromIP(ip);

    const visit: VisitRecord = {
      id: uuidv4(),
      ip: truncateIP(ip),
      ipRaw: ip, // only used internally for geo, not stored in KV accessible fields
      userAgent,
      referer,
      country: geo.country,
      city: geo.city,
      isp: geo.isp,
      visitorId,
      isReturning,
      timestamp: new Date().toISOString(),
      captchaPassed: false,
    };

    // Remove ipRaw before storing
    const { ipRaw: _, ...visitToStore } = visit;
    await pushVisit(visitToStore as VisitRecord);

    // Set visitor cookie (1 year, HttpOnly)
    const response = NextResponse.json({ ok: true, visitorId });
    if (!isReturning) {
      response.cookies.set("visitorId", visitorId, {
        httpOnly: true,
        maxAge: 60 * 60 * 24 * 365,
        path: "/",
        sameSite: "lax",
        secure: process.env.NODE_ENV === "production",
      });
    }

    return response;
  } catch (err) {
    console.error("[visit] error:", err);
    // Never fail visibly
    return NextResponse.json({ ok: false }, { status: 200 });
  }
}
