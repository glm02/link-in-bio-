import { NextRequest, NextResponse } from "next/server";
import { updateCaptchaStatus } from "@/lib/kv";

export const runtime = "nodejs";

interface TurnstileVerifyResponse {
  success: boolean;
  "error-codes"?: string[];
}

export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    const body = await req.json();
    const { token } = body as { token?: string };

    if (!token) {
      return NextResponse.json(
        { success: false, error: "Token manquant" },
        { status: 400 }
      );
    }

    const secret = process.env.TURNSTILE_SECRET_KEY;
    if (!secret) {
      console.error("[captcha] TURNSTILE_SECRET_KEY non défini");
      return NextResponse.json(
        { success: false, error: "Configuration serveur manquante" },
        { status: 500 }
      );
    }

    // Verify with Cloudflare
    const verifyRes = await fetch(
      "https://challenges.cloudflare.com/turnstile/v0/siteverify",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ secret, response: token }),
      }
    );

    const data = (await verifyRes.json()) as TurnstileVerifyResponse;

    if (!data.success) {
      console.warn("[captcha] échec:", data["error-codes"]);
      return NextResponse.json({ success: false, error: "Captcha invalide" });
    }

    // Update captchaPassed in KV for the current visitor
    const visitorId = req.cookies.get("visitorId")?.value;
    if (visitorId) {
      await updateCaptchaStatus(visitorId).catch((e) =>
        console.warn("[captcha] updateCaptchaStatus error:", e)
      );
    }

    return NextResponse.json({ success: true });
  } catch (err) {
    console.error("[captcha] error:", err);
    return NextResponse.json(
      { success: false, error: "Erreur serveur" },
      { status: 500 }
    );
  }
}
