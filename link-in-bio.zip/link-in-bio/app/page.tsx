"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";

type Stage = "loading" | "captcha" | "verifying" | "success" | "error";

declare global {
  interface Window {
    turnstile: {
      render: (
        container: string | HTMLElement,
        options: {
          sitekey: string;
          callback: (token: string) => void;
          "error-callback": () => void;
          theme: string;
          size: string;
        }
      ) => string;
      remove: (widgetId: string) => void;
    };
  }
}

export default function HomePage() {
  const router = useRouter();
  const [stage, setStage] = useState<Stage>("loading");
  const [dots, setDots] = useState(".");
  const turnstileRef = useRef<HTMLDivElement>(null);
  const widgetIdRef = useRef<string | null>(null);

  // Animated dots
  useEffect(() => {
    const interval = setInterval(() => {
      setDots((d) => (d.length >= 3 ? "." : d + "."));
    }, 400);
    return () => clearInterval(interval);
  }, []);

  // Fire & forget visit tracking
  useEffect(() => {
    fetch("/api/visit", { method: "POST" }).catch(() => {});
  }, []);

  // Show captcha after 1.2s loader
  useEffect(() => {
    const timer = setTimeout(() => setStage("captcha"), 1200);
    return () => clearTimeout(timer);
  }, []);

  // Render Turnstile widget when captcha stage is active
  useEffect(() => {
    if (stage !== "captcha") return;

    const sitekey = process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY;
    if (!sitekey) {
      console.warn("Turnstile sitekey manquant");
      return;
    }

    // Wait for the script to load
    const tryRender = () => {
      if (window.turnstile && turnstileRef.current) {
        widgetIdRef.current = window.turnstile.render(turnstileRef.current, {
          sitekey,
          theme: "dark",
          size: "normal",
          callback: async (token: string) => {
            setStage("verifying");
            try {
              const res = await fetch("/api/verify-captcha", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ token }),
              });
              const data = await res.json();
              if (data.success) {
                setStage("success");
                setTimeout(() => {
                  const redirect =
                    process.env.NEXT_PUBLIC_REDIRECT_URL || "https://linktr.ee";
                  router.push(redirect);
                }, 1000);
              } else {
                setStage("error");
              }
            } catch {
              setStage("error");
            }
          },
          "error-callback": () => setStage("error"),
        });
      } else {
        setTimeout(tryRender, 200);
      }
    };

    tryRender();

    return () => {
      if (widgetIdRef.current && window.turnstile) {
        window.turnstile.remove(widgetIdRef.current);
      }
    };
  }, [stage, router]);

  return (
    <main className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden bg-surface">
      {/* Background gradient orbs */}
      <div
        className="absolute inset-0 pointer-events-none"
        aria-hidden="true"
      >
        <div
          style={{
            position: "absolute",
            top: "20%",
            left: "50%",
            transform: "translateX(-50%)",
            width: "600px",
            height: "600px",
            borderRadius: "50%",
            background:
              "radial-gradient(circle, rgba(99,102,241,0.12) 0%, transparent 70%)",
            filter: "blur(40px)",
          }}
        />
        <div
          style={{
            position: "absolute",
            bottom: "10%",
            right: "10%",
            width: "300px",
            height: "300px",
            borderRadius: "50%",
            background:
              "radial-gradient(circle, rgba(139,92,246,0.08) 0%, transparent 70%)",
            filter: "blur(30px)",
          }}
        />
      </div>

      {/* Card */}
      <div
        style={{
          position: "relative",
          zIndex: 10,
          width: "100%",
          maxWidth: "420px",
          margin: "0 auto",
          padding: "2.5rem 2rem",
          background: "rgba(19,19,26,0.8)",
          border: "1px solid rgba(99,102,241,0.15)",
          borderRadius: "24px",
          backdropFilter: "blur(20px)",
          boxShadow:
            "0 0 0 1px rgba(99,102,241,0.05), 0 20px 80px rgba(0,0,0,0.5)",
          textAlign: "center",
        }}
      >
        {/* Logo / Icon */}
        <div
          style={{
            width: "56px",
            height: "56px",
            borderRadius: "16px",
            background: "linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)",
            margin: "0 auto 1.5rem",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            boxShadow: "0 8px 24px rgba(99,102,241,0.35)",
          }}
        >
          <svg
            width="28"
            height="28"
            viewBox="0 0 24 24"
            fill="none"
            stroke="white"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
          </svg>
        </div>

        {/* Loading Stage */}
        {(stage === "loading" || stage === "captcha" || stage === "verifying") && (
          <>
            <h1
              style={{
                fontSize: "1.25rem",
                fontWeight: 600,
                color: "#e2e8f0",
                marginBottom: "0.5rem",
                letterSpacing: "-0.02em",
              }}
            >
              {stage === "loading" && "Chargement" + dots}
              {stage === "captcha" && "Vérification de sécurité"}
              {stage === "verifying" && "Validation" + dots}
            </h1>
            <p
              style={{
                fontSize: "0.875rem",
                color: "#6b7280",
                marginBottom: "2rem",
              }}
            >
              {stage === "loading" && "Initialisation en cours..."}
              {stage === "captcha" &&
                "Complétez la vérification pour continuer"}
              {stage === "verifying" && "Vérification de votre réponse..."}
            </p>
          </>
        )}

        {/* Loader spinner */}
        {stage === "loading" && (
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              marginBottom: "1rem",
            }}
          >
            <div
              style={{
                width: "40px",
                height: "40px",
                border: "3px solid rgba(99,102,241,0.2)",
                borderTopColor: "#6366f1",
                borderRadius: "50%",
                animation: "spin 0.8s linear infinite",
              }}
            />
          </div>
        )}

        {/* Turnstile container */}
        {stage === "captcha" && (
          <div
            ref={turnstileRef}
            style={{ display: "flex", justifyContent: "center" }}
          />
        )}

        {/* Verifying spinner */}
        {stage === "verifying" && (
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              marginBottom: "1rem",
            }}
          >
            <div
              style={{
                width: "40px",
                height: "40px",
                border: "3px solid rgba(99,102,241,0.2)",
                borderTopColor: "#6366f1",
                borderRadius: "50%",
                animation: "spin 0.8s linear infinite",
              }}
            />
          </div>
        )}

        {/* Success */}
        {stage === "success" && (
          <div style={{ animation: "scaleIn 0.4s cubic-bezier(0.34,1.56,0.64,1) forwards" }}>
            <div
              style={{
                width: "64px",
                height: "64px",
                borderRadius: "50%",
                background: "rgba(34,197,94,0.15)",
                border: "2px solid rgba(34,197,94,0.4)",
                margin: "0 auto 1.5rem",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <svg
                width="32"
                height="32"
                viewBox="0 0 24 24"
                fill="none"
                stroke="#22c55e"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <polyline points="20 6 9 17 4 12" />
              </svg>
            </div>
            <h1
              style={{
                fontSize: "1.25rem",
                fontWeight: 600,
                color: "#22c55e",
                marginBottom: "0.5rem",
              }}
            >
              Vérifié !
            </h1>
            <p style={{ fontSize: "0.875rem", color: "#6b7280" }}>
              Redirection en cours...
            </p>
          </div>
        )}

        {/* Error */}
        {stage === "error" && (
          <div>
            <div
              style={{
                width: "64px",
                height: "64px",
                borderRadius: "50%",
                background: "rgba(239,68,68,0.12)",
                border: "2px solid rgba(239,68,68,0.3)",
                margin: "0 auto 1.5rem",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <svg
                width="32"
                height="32"
                viewBox="0 0 24 24"
                fill="none"
                stroke="#ef4444"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <line x1="18" y1="6" x2="6" y2="18" />
                <line x1="6" y1="6" x2="18" y2="18" />
              </svg>
            </div>
            <h1
              style={{
                fontSize: "1.25rem",
                fontWeight: 600,
                color: "#ef4444",
                marginBottom: "0.5rem",
              }}
            >
              Erreur de vérification
            </h1>
            <p
              style={{
                fontSize: "0.875rem",
                color: "#6b7280",
                marginBottom: "1.5rem",
              }}
            >
              La vérification a échoué. Veuillez réessayer.
            </p>
            <button
              onClick={() => setStage("captcha")}
              style={{
                padding: "0.625rem 1.5rem",
                background: "linear-gradient(135deg, #6366f1, #8b5cf6)",
                border: "none",
                borderRadius: "10px",
                color: "white",
                fontSize: "0.875rem",
                fontWeight: 500,
                cursor: "pointer",
              }}
            >
              Réessayer
            </button>
          </div>
        )}
      </div>

      {/* RGPD notice */}
      <p
        style={{
          position: "absolute",
          bottom: "1.5rem",
          left: "50%",
          transform: "translateX(-50%)",
          fontSize: "0.7rem",
          color: "rgba(107,114,128,0.6)",
          whiteSpace: "nowrap",
          zIndex: 10,
        }}
      >
        Votre IP est collectée à des fins de sécurité — conforme RGPD / CNIL
      </p>

      <style>{`
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
        @keyframes scaleIn {
          from { opacity: 0; transform: scale(0.5); }
          to { opacity: 1; transform: scale(1); }
        }
      `}</style>
    </main>
  );
}
