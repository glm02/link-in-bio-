import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Vérification en cours...",
  description: "Vérification de sécurité",
  robots: "noindex, nofollow",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fr">
      <head>
        <script
          src="https://challenges.cloudflare.com/turnstile/v0/api.js"
          async
          defer
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
