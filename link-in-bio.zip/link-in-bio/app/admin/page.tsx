"use client";

import { useEffect, useState, useCallback } from "react";
import { useSearchParams } from "next/navigation";
import type { VisitRecord } from "@/lib/kv";

function parseUA(ua: string): string {
  if (!ua || ua === "Inconnu") return "Inconnu";
  if (/Instagram/i.test(ua)) return "Instagram";
  if (/TikTok/i.test(ua)) return "TikTok";
  if (/Twitter/i.test(ua)) return "Twitter/X";
  if (/Facebook/i.test(ua)) return "Facebook";
  if (/Chrome/i.test(ua)) return "Chrome";
  if (/Firefox/i.test(ua)) return "Firefox";
  if (/Safari/i.test(ua)) return "Safari";
  if (/Edge/i.test(ua)) return "Edge";
  if (/bot|crawl|spider/i.test(ua)) return "Bot";
  return "Autre";
}

function parseReferer(ref: string): string {
  if (!ref || ref === "Direct") return "Direct";
  try {
    const url = new URL(ref);
    const host = url.hostname.replace("www.", "");
    if (host.includes("instagram")) return "Instagram";
    if (host.includes("tiktok")) return "TikTok";
    if (host.includes("twitter") || host.includes("x.com")) return "Twitter/X";
    if (host.includes("facebook")) return "Facebook";
    if (host.includes("youtube")) return "YouTube";
    if (host.includes("snapchat")) return "Snapchat";
    if (host.includes("linktree")) return "Linktree";
    return host;
  } catch {
    return ref.substring(0, 30);
  }
}

function formatDate(iso: string): string {
  try {
    return new Date(iso).toLocaleString("fr-FR", {
      day: "2-digit",
      month: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return iso;
  }
}

const PLATFORM_COLORS: Record<string, string> = {
  Instagram: "#e1306c",
  TikTok: "#00f2ea",
  "Twitter/X": "#1da1f2",
  Facebook: "#4267b2",
  YouTube: "#ff0000",
  Snapchat: "#fffc00",
  Direct: "#6b7280",
};

export default function AdminPage() {
  const searchParams = useSearchParams();
  const key = searchParams.get("key") ?? "";
  const adminKey = process.env.NEXT_PUBLIC_ADMIN_KEY ?? "";

  const [visits, setVisits] = useState<VisitRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [authorized, setAuthorized] = useState(false);
  const [clearing, setClearing] = useState(false);

  const fetchVisits = useCallback(async () => {
    try {
      const res = await fetch(`/api/admin/visits?key=${encodeURIComponent(key)}`);
      if (res.status === 401) {
        setAuthorized(false);
        return;
      }
      const data = await res.json();
      setVisits(data.visits ?? []);
      setAuthorized(true);
    } catch {
      // silently fail
    } finally {
      setLoading(false);
    }
  }, [key]);

  useEffect(() => {
    fetchVisits();
    const interval = setInterval(fetchVisits, 30_000);
    return () => clearInterval(interval);
  }, [fetchVisits]);

  const handleClear = async () => {
    if (!confirm("Effacer tous les logs ? Cette action est irréversible.")) return;
    setClearing(true);
    await fetch(`/api/admin/visits?key=${encodeURIComponent(key)}`, {
      method: "DELETE",
    });
    setVisits([]);
    setClearing(false);
  };

  // Auth check — compare key against env
  const isAuth = key && (authorized || key === adminKey);

  if (!key || (!loading && !authorized)) {
    return (
      <div
        style={{
          minHeight: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexDirection: "column",
          gap: "1rem",
          background: "#0a0a0f",
        }}
      >
        <div
          style={{
            width: "56px",
            height: "56px",
            borderRadius: "50%",
            background: "rgba(239,68,68,0.12)",
            border: "2px solid rgba(239,68,68,0.3)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="2">
            <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
            <path d="M7 11V7a5 5 0 0 1 10 0v4" />
          </svg>
        </div>
        <h1 style={{ color: "#ef4444", fontSize: "1.25rem", fontWeight: 600 }}>
          Accès refusé
        </h1>
        <p style={{ color: "#6b7280", fontSize: "0.875rem" }}>
          Accès via <code style={{ color: "#6366f1" }}>/admin?key=VOTRE_CLE</code>
        </p>
      </div>
    );
  }

  // Stats
  const total = visits.length;
  const unique = new Set(visits.map((v) => v.visitorId)).size;
  const captchaPassed = visits.filter((v) => v.captchaPassed).length;
  const captchaRate = total > 0 ? Math.round((captchaPassed / total) * 100) : 0;

  const countryCounts: Record<string, number> = {};
  visits.forEach((v) => {
    countryCounts[v.country] = (countryCounts[v.country] ?? 0) + 1;
  });
  const topCountry =
    Object.entries(countryCounts).sort((a, b) => b[1] - a[1])[0]?.[0] ?? "—";

  const refererCounts: Record<string, number> = {};
  visits.forEach((v) => {
    const r = parseReferer(v.referer);
    refererCounts[r] = (refererCounts[r] ?? 0) + 1;
  });

  return (
    <div style={{ minHeight: "100vh", background: "#0a0a0f", color: "#e2e8f0", fontFamily: "system-ui, sans-serif" }}>
      {/* Header */}
      <div
        style={{
          borderBottom: "1px solid rgba(99,102,241,0.15)",
          padding: "1.25rem 2rem",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          background: "rgba(19,19,26,0.8)",
          backdropFilter: "blur(20px)",
          position: "sticky",
          top: 0,
          zIndex: 10,
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
          <div
            style={{
              width: "36px",
              height: "36px",
              borderRadius: "10px",
              background: "linear-gradient(135deg, #6366f1, #8b5cf6)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
            </svg>
          </div>
          <div>
            <h1 style={{ fontSize: "1rem", fontWeight: 700, margin: 0 }}>
              Dashboard Admin
            </h1>
            <p style={{ fontSize: "0.7rem", color: "#6b7280", margin: 0 }}>
              Auto-refresh · 30s
            </p>
          </div>
        </div>
        <button
          onClick={handleClear}
          disabled={clearing || total === 0}
          style={{
            padding: "0.5rem 1rem",
            background: "rgba(239,68,68,0.1)",
            border: "1px solid rgba(239,68,68,0.3)",
            borderRadius: "8px",
            color: "#ef4444",
            fontSize: "0.8rem",
            fontWeight: 500,
            cursor: clearing || total === 0 ? "not-allowed" : "pointer",
            opacity: clearing || total === 0 ? 0.5 : 1,
          }}
        >
          {clearing ? "Effacement..." : "Effacer les logs"}
        </button>
      </div>

      <div style={{ padding: "2rem", maxWidth: "1400px", margin: "0 auto" }}>
        {loading ? (
          <div style={{ display: "flex", justifyContent: "center", paddingTop: "4rem" }}>
            <div
              style={{
                width: "40px",
                height: "40px",
                border: "3px solid rgba(99,102,241,0.2)",
                borderTopColor: "#6366f1",
                borderRadius: "50%",
                animation: "spin 0.8s linear infinite",
              }}
            />
          </div>
        ) : (
          <>
            {/* Stats cards */}
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))",
                gap: "1rem",
                marginBottom: "2rem",
              }}
            >
              {[
                { label: "Visites totales", value: total, icon: "👁", color: "#6366f1" },
                { label: "Visiteurs uniques", value: unique, icon: "👤", color: "#8b5cf6" },
                { label: "Captcha réussi", value: `${captchaRate}%`, icon: "✓", color: "#22c55e" },
                { label: "Top pays", value: topCountry, icon: "🌍", color: "#f59e0b" },
              ].map((stat) => (
                <div
                  key={stat.label}
                  style={{
                    background: "rgba(19,19,26,0.8)",
                    border: `1px solid rgba(${stat.color === "#6366f1" ? "99,102,241" : stat.color === "#8b5cf6" ? "139,92,246" : stat.color === "#22c55e" ? "34,197,94" : "245,158,11"},0.2)`,
                    borderRadius: "14px",
                    padding: "1.25rem",
                  }}
                >
                  <div style={{ fontSize: "1.5rem", marginBottom: "0.5rem" }}>{stat.icon}</div>
                  <div style={{ fontSize: "1.75rem", fontWeight: 700, color: stat.color }}>
                    {stat.value}
                  </div>
                  <div style={{ fontSize: "0.75rem", color: "#6b7280", marginTop: "0.25rem" }}>
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>

            {/* Sources breakdown */}
            {Object.keys(refererCounts).length > 0 && (
              <div
                style={{
                  background: "rgba(19,19,26,0.8)",
                  border: "1px solid rgba(99,102,241,0.15)",
                  borderRadius: "14px",
                  padding: "1.25rem",
                  marginBottom: "2rem",
                }}
              >
                <h2 style={{ fontSize: "0.85rem", fontWeight: 600, color: "#94a3b8", marginBottom: "1rem", textTransform: "uppercase", letterSpacing: "0.05em" }}>
                  Sources de trafic
                </h2>
                <div style={{ display: "flex", flexWrap: "wrap", gap: "0.75rem" }}>
                  {Object.entries(refererCounts)
                    .sort((a, b) => b[1] - a[1])
                    .map(([source, count]) => (
                      <div
                        key={source}
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: "0.5rem",
                          padding: "0.4rem 0.75rem",
                          background: "rgba(255,255,255,0.04)",
                          borderRadius: "8px",
                          fontSize: "0.8rem",
                        }}
                      >
                        <span
                          style={{
                            width: "8px",
                            height: "8px",
                            borderRadius: "50%",
                            background: PLATFORM_COLORS[source] ?? "#6b7280",
                            flexShrink: 0,
                          }}
                        />
                        <span style={{ color: "#e2e8f0" }}>{source}</span>
                        <span
                          style={{
                            background: "rgba(99,102,241,0.2)",
                            color: "#818cf8",
                            padding: "0.1rem 0.4rem",
                            borderRadius: "4px",
                            fontWeight: 600,
                          }}
                        >
                          {count}
                        </span>
                      </div>
                    ))}
                </div>
              </div>
            )}

            {/* Visits table */}
            <div
              style={{
                background: "rgba(19,19,26,0.8)",
                border: "1px solid rgba(99,102,241,0.15)",
                borderRadius: "14px",
                overflow: "hidden",
              }}
            >
              <div style={{ padding: "1.25rem 1.5rem", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
                <h2 style={{ fontSize: "0.85rem", fontWeight: 600, color: "#94a3b8", textTransform: "uppercase", letterSpacing: "0.05em", margin: 0 }}>
                  Logs de visites ({total})
                </h2>
              </div>

              {total === 0 ? (
                <div style={{ padding: "3rem", textAlign: "center", color: "#6b7280" }}>
                  Aucune visite enregistrée
                </div>
              ) : (
                <div style={{ overflowX: "auto" }}>
                  <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "0.8rem" }}>
                    <thead>
                      <tr style={{ borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
                        {["IP", "Pays", "Ville", "FAI", "Navigateur", "Source", "Heure", "Captcha", "Type"].map((h) => (
                          <th
                            key={h}
                            style={{
                              padding: "0.75rem 1rem",
                              textAlign: "left",
                              color: "#6b7280",
                              fontWeight: 500,
                              whiteSpace: "nowrap",
                            }}
                          >
                            {h}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {visits.map((visit, i) => {
                        const source = parseReferer(visit.referer);
                        const browser = parseUA(visit.userAgent);
                        const sourceColor = PLATFORM_COLORS[source];
                        return (
                          <tr
                            key={visit.id}
                            style={{
                              borderBottom: i < visits.length - 1 ? "1px solid rgba(255,255,255,0.04)" : "none",
                              background: i % 2 === 0 ? "transparent" : "rgba(255,255,255,0.01)",
                            }}
                          >
                            <td style={{ padding: "0.75rem 1rem", fontFamily: "monospace", color: "#94a3b8" }}>
                              {visit.ip}
                            </td>
                            <td style={{ padding: "0.75rem 1rem", color: "#e2e8f0" }}>
                              {visit.country}
                            </td>
                            <td style={{ padding: "0.75rem 1rem", color: "#94a3b8" }}>
                              {visit.city}
                            </td>
                            <td
                              style={{
                                padding: "0.75rem 1rem",
                                color: "#94a3b8",
                                maxWidth: "150px",
                                overflow: "hidden",
                                textOverflow: "ellipsis",
                                whiteSpace: "nowrap",
                              }}
                            >
                              {visit.isp}
                            </td>
                            <td style={{ padding: "0.75rem 1rem", color: "#e2e8f0" }}>
                              {browser}
                            </td>
                            <td style={{ padding: "0.75rem 1rem" }}>
                              <span
                                style={{
                                  display: "inline-flex",
                                  alignItems: "center",
                                  gap: "0.35rem",
                                  fontSize: "0.75rem",
                                }}
                              >
                                {sourceColor && (
                                  <span
                                    style={{
                                      width: "7px",
                                      height: "7px",
                                      borderRadius: "50%",
                                      background: sourceColor,
                                      flexShrink: 0,
                                    }}
                                  />
                                )}
                                <span style={{ color: "#94a3b8" }}>{source}</span>
                              </span>
                            </td>
                            <td style={{ padding: "0.75rem 1rem", color: "#6b7280", whiteSpace: "nowrap" }}>
                              {formatDate(visit.timestamp)}
                            </td>
                            <td style={{ padding: "0.75rem 1rem", textAlign: "center" }}>
                              {visit.captchaPassed ? (
                                <span style={{ color: "#22c55e", fontSize: "1rem" }}>✓</span>
                              ) : (
                                <span style={{ color: "#ef4444", fontSize: "1rem" }}>✗</span>
                              )}
                            </td>
                            <td style={{ padding: "0.75rem 1rem" }}>
                              <span
                                style={{
                                  padding: "0.2rem 0.5rem",
                                  borderRadius: "6px",
                                  fontSize: "0.7rem",
                                  fontWeight: 600,
                                  background: visit.isReturning
                                    ? "rgba(139,92,246,0.15)"
                                    : "rgba(34,197,94,0.1)",
                                  color: visit.isReturning ? "#a78bfa" : "#4ade80",
                                }}
                              >
                                {visit.isReturning ? "Retour" : "Nouveau"}
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </>
        )}
      </div>

      <style>{`
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}
