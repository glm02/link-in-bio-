interface GeoResult {
  country: string;
  city: string;
  isp: string;
}

const FALLBACK: GeoResult = {
  country: "Inconnu",
  city: "Inconnue",
  isp: "Inconnu",
};

export async function getGeoFromIP(ip: string): Promise<GeoResult> {
  // Skip private / loopback IPs
  if (
    !ip ||
    ip === "127.0.0.1" ||
    ip === "::1" ||
    ip.startsWith("192.168.") ||
    ip.startsWith("10.") ||
    ip.startsWith("172.")
  ) {
    return { country: "Local", city: "Local", isp: "Local" };
  }

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 3000);

    const res = await fetch(`http://ip-api.com/json/${ip}?fields=country,city,isp,status`, {
      signal: controller.signal,
    });
    clearTimeout(timeout);

    if (!res.ok) return FALLBACK;

    const data = await res.json();
    if (data.status !== "success") return FALLBACK;

    return {
      country: data.country ?? "Inconnu",
      city: data.city ?? "Inconnue",
      isp: data.isp ?? "Inconnu",
    };
  } catch {
    return FALLBACK;
  }
}

/**
 * Truncate IP to 3 octets for CNIL compliance.
 * IPv4: 192.168.1.123 → 192.168.1.xxx
 * IPv6: 2001:db8::1 → 2001:db8::xxx
 */
export function truncateIP(ip: string): string {
  if (!ip) return "xxx";

  // IPv4
  if (ip.includes(".")) {
    const parts = ip.split(".");
    if (parts.length === 4) {
      return `${parts[0]}.${parts[1]}.${parts[2]}.xxx`;
    }
  }

  // IPv6 — anonymize the last group
  if (ip.includes(":")) {
    const parts = ip.split(":");
    parts[parts.length - 1] = "xxxx";
    return parts.join(":");
  }

  return "xxx";
}
