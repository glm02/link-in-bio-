import { kv } from "@vercel/kv";

export interface VisitRecord {
  id: string;
  ip: string;
  ipRaw: string; // truncated for display
  userAgent: string;
  referer: string;
  country: string;
  city: string;
  isp: string;
  visitorId: string;
  isReturning: boolean;
  timestamp: string;
  captchaPassed: boolean;
}

const VISITS_KEY = "visits";
const MAX_VISITS = 1000; // cap stored visits

export async function pushVisit(visit: VisitRecord): Promise<void> {
  await kv.lpush(VISITS_KEY, JSON.stringify(visit));
  // Keep only the latest MAX_VISITS records
  await kv.ltrim(VISITS_KEY, 0, MAX_VISITS - 1);
}

export async function getVisits(): Promise<VisitRecord[]> {
  const raw = await kv.lrange<string>(VISITS_KEY, 0, -1);
  return raw.map((item) => {
    if (typeof item === "string") {
      return JSON.parse(item) as VisitRecord;
    }
    return item as VisitRecord;
  });
}

export async function updateCaptchaStatus(visitorId: string): Promise<void> {
  const raw = await kv.lrange<string>(VISITS_KEY, 0, -1);
  const visits = raw.map((item) => {
    const v: VisitRecord =
      typeof item === "string" ? JSON.parse(item) : item;
    if (v.visitorId === visitorId) {
      return { ...v, captchaPassed: true };
    }
    return v;
  });

  // Re-write the list
  await kv.del(VISITS_KEY);
  if (visits.length > 0) {
    await kv.rpush(VISITS_KEY, ...visits.map((v) => JSON.stringify(v)));
  }
}

export async function clearVisits(): Promise<void> {
  await kv.del(VISITS_KEY);
}

export { kv };
